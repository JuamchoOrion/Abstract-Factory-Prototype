package co.edu.uniquindio.poo;

/**
 * Hello world!
 *
 */
public class App {

        /**
 * La clase { App} contiene el metodo principal ({ main}) para probar el funcionamiento
 * del patron Abstract Factory en un entorno de restaurantes chinos y mexicanos.
 */
    public static void main(String[] args) {

        RestauranteFactory restauranteChinoFactory = new RestauranteChinoFactory();

        Cliente clienteChino = new Cliente(restauranteChinoFactory);

        clienteChino.createUI();

        clienteChino.paint();


        RestauranteFactory restauranteMexicanoFactory = new RestauranteMexicanoFactory();

        Cliente clienteMexicano = new Cliente(restauranteMexicanoFactory);

        clienteMexicano.createUI();

        clienteMexicano.paint();

    }
}



