package co.edu.uniquindio.poo;

/**
 * La clase {ComidaMexicana} implementa la interfaz {AbstractComida},
 * representando una comida de un restaurante mexicano.
 */
public class ComidaMexicana implements AbstractComida {
    
     private String name;
     
     public ComidaMexicana(){
        
     }
     
      @Override
    public void preparar() {
      System.out.println("Preparando comida mexicana");
    }
}
