package co.edu.uniquindio.poo;

// Clase principal que prueba la funcionalidad de clonación del personaje
public class Main {
    public static void main(String[] args) {
        // Se crea un objeto de tipo Personaje
        Personaje personaje = new Personaje("Juan", 200, "paladin");
        
        // Se clona el personaje
        Personaje personajeClon = (Personaje) personaje.clonar();
        
        // Se verifica si el clon fue creado correctamente
        if(personajeClon != null){
            // Se imprime el personaje clonado
            System.out.println("Personaje clonado: " + personajeClon);
        } else {
            // En caso de que el clon no se haya creado correctamente
            // (esto no debería ocurrir en este ejemplo)
            System.out.println("Error al clonar el personaje.");
        }
    }
}
