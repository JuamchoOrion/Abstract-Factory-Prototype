package co.edu.uniquindio.poo;

/**
 * Hello world!
 *
 */
public class App {

            //Que se debe hacer
        //-Probar el funcionamiento del patron
            //-Probar el correcto funcionamiento de los metodos
    public static void main(String[] args) {

        RestauranteFactory restauranteChinoFactory = new RestauranteChinoFactory();

        Cliente clienteChino = new Cliente(restauranteChinoFactory);

        clienteChino.createUI();

        clienteChino.paint();


        RestauranteFactory restauranteMexicanoFactory = new RestauranteMexicanoFactory();

        Cliente clienteMexicano = new Cliente(restauranteMexicanoFactory);

        clienteMexicano.createUI();

        clienteMexicano.paint();

    }
}



