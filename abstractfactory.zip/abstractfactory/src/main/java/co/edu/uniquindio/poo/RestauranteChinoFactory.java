package co.edu.uniquindio.poo;

/*Esta fábrica concreta se utiliza para crear objetos específicos de un restaurante chino, 
asegurando la coherencia entre los productos creados*/
public class RestauranteChinoFactory implements RestauranteFactory {
    private MenuChino menu;
    private ComidaChina comida;
    
    @Override
    public AbstractMenu crearAbstractMenu()  {
    return new MenuChino();
    }

    @Override
    public AbstractComida crearAbstractComida() {
    return new ComidaChina();
    }
}
/*La utilización de la interfaz RestauranteFactory permite que esta clase se integre en un 
sistema que utiliza patrones de diseño para la creación de objetos.*/