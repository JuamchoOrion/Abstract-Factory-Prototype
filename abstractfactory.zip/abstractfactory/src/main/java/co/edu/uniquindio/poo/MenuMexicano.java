package co.edu.uniquindio.poo;
/**
 * La clase {@code MenuMexicano} implementa la interfaz {@code AbstractMenu},
 * representando un menu especifico de un restaurante mexicano.
 */
public class MenuMexicano implements AbstractMenu {
    private String nombre;
    
    public MenuMexicano() {
    }
    @Override
    public void leer() {
        System.out.println("leyendo");
    }

        @Override
    public String getNombre() {
        return nombre;
    }
}
