package co.edu.uniquindio.poo;

/* Esta fabrica es igual a la anterior solo enfocandose en elementos de restaurante mexicano*/
public class RestauranteMexicanoFactory implements RestauranteFactory {
    private ComidaMexicana comida;
    private MenuMexicano menu;

    @Override
    public AbstractComida crearAbstractComida(){
        return new ComidaMexicana();
    }

    @Override
    public AbstractMenu crearAbstractMenu(){
        return new MenuMexicano();
    }
}
