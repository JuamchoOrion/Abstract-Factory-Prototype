package co.edu.uniquindio.poo;
interface  AbstractRestauranteFactory {

}
