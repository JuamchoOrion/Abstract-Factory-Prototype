package co.edu.uniquindio.poo;
// no puede ser interface
interface AbstractMenu {
    void leer();
    String getNombre();
}
