package co.edu.uniquindio.poo;


public interface AbstractComida {
    void preparar();
}