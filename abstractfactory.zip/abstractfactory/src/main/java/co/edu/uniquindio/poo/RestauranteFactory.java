package co.edu.uniquindio.poo;

/*El propósito principal de esta interfaz es proporcionar una abstracción para la creación de familias
 de objetos (menús y comidas) que deben ser compatibles entre sí*/
 
interface RestauranteFactory {              
    AbstractMenu crearAbstractMenu();
    AbstractComida crearAbstractComida();
}
