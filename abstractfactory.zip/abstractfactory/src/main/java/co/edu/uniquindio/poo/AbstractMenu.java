package co.edu.uniquindio.poo;
/*Los metodos aqui definidos proporcionan una abstraccion para las operaciones comunes que se esperan 
de cualquier menu en el sistema. La implementacion exacta
 puede variar segun el tipo especifico de menu*/
interface AbstractMenu {
    void leer();
    String getNombre();
}
