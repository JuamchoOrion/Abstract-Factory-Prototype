package co.edu.uniquindio.poo;

public class MenuChino implements AbstractMenu {
    
    private String name;
     
    public MenuChino() {
        
    }
    @Override
    public String getNombre() {
        return name;
    }
    @Override
    public void leer() {
      System.out.println("leyendo");
    }
}
