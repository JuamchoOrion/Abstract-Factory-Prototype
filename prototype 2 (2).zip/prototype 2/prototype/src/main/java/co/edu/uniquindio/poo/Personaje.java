package co.edu.uniquindio.poo;

public class Personaje implements Ipersonaje{
    private String nombre;
    private int fuerza;
    private String tipo;
// Constructor para inicializar los campos del personaje
    public Personaje(String nombre, int fuerza, String tipo){
        assert nombre != null;
        this.nombre = nombre;
        this.fuerza = fuerza;
        this.tipo = tipo;
    }
     // Métodos para establecer los valores de los campos
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setFuerza(int fuerza) {
        this.fuerza = fuerza;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public Ipersonaje clonar() {
        Personaje personaje = null;
        // Utiliza el método clone() para obtener una copia
        try{
            personaje = (Personaje) clone();//mapeo se busca obtener un clon de esa instancia
        }catch(CloneNotSupportedException e){
            e.printStackTrace();
        }
        return personaje;
    }
// Método toString para representar el objeto como una cadena de texto
    @Override
    public String toString(){
        return "Personaje "+ " [ nombre: "+nombre+" fuerza: "+fuerza+ " tipo: "+tipo+"]";
    }
}
