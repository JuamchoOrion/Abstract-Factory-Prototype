package co.edu.uniquindio.poo;

public class ComidaChina implements AbstractComida  {
    
    private String name;

    public ComidaChina(){

        
    }

 @Override
    public void preparar() {
        System.out.println("Preparando comida china");
    }
}
