package co.edu.uniquindio.poo;

public class Cliente {
    private RestauranteFactory factory;
    private AbstractComida comida;
    private AbstractMenu menu;


public Cliente(RestauranteFactory factory) {
        this.factory = factory;
    }


public RestauranteFactory getFactory() {
    return factory;
}


public AbstractComida getComida() {
    return comida;
}


public AbstractMenu getMenu() {
    return menu;
}

public void createUI(){
    this.comida = factory.crearAbstractComida();
    this.menu = factory.crearAbstractMenu();
}

public void paint() {
        comida.preparar();
        System.out.println("Nombre del menú: " + menu.getNombre());
        System.out.println("Tipo de comida: " + comida.getClass().getSimpleName());
        menu.leer();
}

}
