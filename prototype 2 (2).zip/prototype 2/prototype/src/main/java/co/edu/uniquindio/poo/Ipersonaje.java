package co.edu.uniquindio.poo;
//interfaz que implementa cloneable
public interface Ipersonaje extends Cloneable {
    //metodo clonar para crera una copia de personaje
    Ipersonaje clonar();
    
}
