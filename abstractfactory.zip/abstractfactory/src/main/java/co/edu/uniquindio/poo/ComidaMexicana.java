package co.edu.uniquindio.poo;

public class ComidaMexicana implements AbstractComida {
    
     private String name;
     
     public ComidaMexicana(){
        
     }
     
      @Override
    public void preparar() {
      System.out.println("Preparando comida mexicana");
    }
}
