package co.edu.uniquindio.poo;
 /**
     * Realiza las acciones necesarias para preparar la comida.
     * La implementacion concreta de este metodo puede variar segun la naturaleza de la comida.
     */

public interface AbstractComida {
    void preparar();
}